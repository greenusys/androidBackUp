<?php include 'session.php'; ?>
<?php include 'public/menubar.php'; ?>
<!-- <script src="https://cdn.ckeditor.com/4.11.2/standard/ckeditor.js"></script> -->
<script src="assets/js/ckeditor/ckeditor.js"></script>
<?php include 'public/edit-help-form.php'; ?>
<?php include 'public/footer.php'; ?>