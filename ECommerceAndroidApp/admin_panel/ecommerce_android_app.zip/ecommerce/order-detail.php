<?php include 'session.php'; ?>
<?php include 'public/menubar.php'; ?>
<style type="text/css">
	.my-pre {
		font-size: 16px;
		font-family: 'lato', sans-serif;
		border: 0; 
		background-color: transparent;
		padding: 0px;
	}
</style>
<?php include 'public/data-order-detail.php'; ?>
<?php include 'public/footer.php'; ?>